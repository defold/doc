# Infinite runner sample
Infinite runner sample project for Defold. Follow tutorial here: https://defold.com/tutorials/runner/

![](preview.png)
